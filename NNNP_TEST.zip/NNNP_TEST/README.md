## CLI usage

#### Generate batch file
`[Python Exec] mlp_tests_gen.py`

#### Run test directly (Recommend)
`[Python Exec] mlp_test_gen.py -R`

#### Setup test env
Modify `config.json`, then `mlp_test_gen.py` will generate all test cases.

#### Test Configures
Use `run_all_tests.py` to run all the test configure file (`.json`) in `./test_config`.

#### More Info
Use `[command] --help` to get help docs of CLI tools.